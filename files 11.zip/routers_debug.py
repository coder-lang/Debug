# routers/debug.py
# ================
# POST /debug/chunks
#
# Returns the EXACT chunks passed to the LLM — mirrors the full
# chat_service.py pipeline step by step:
#   1. Translate query to Hindi  (same as chat_service)
#   2. fetch_k = 40 from vectorstore  (same as chat_service)
#   3. Balance: max 3 chunks per document  (same as chat_service)
#   4. Year filter if year in query  (same as chat_service)
#
# What Streamlit shows = What LLM actually receives ✅

import re
from typing import List, Optional
from fastapi import APIRouter, Request
from pydantic import BaseModel

from services.vector_service import search_vectorstore
from core.config import (
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_KEY,
    AZURE_OPENAI_API_VERSION,
    CHAT_DEPLOYMENT,
)
from openai import AzureOpenAI

router = APIRouter(prefix="/debug", tags=["Debug"])

_openai_client = AzureOpenAI(
    api_key=AZURE_OPENAI_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)


# ── Helpers (copied exactly from chat_service.py) ─────────────────────────────

def extract_years_from_query(query: str) -> List[str]:
    years = set()
    for match in re.findall(r"(20\d{2})[-–]((\d{2})|20\d{2})", query):
        years.add(match[0])
        suffix = match[1]
        years.add(match[0][:2] + suffix if len(suffix) == 2 else suffix)
    for y in re.findall(r"\b(20\d{2})\b", query):
        years.add(y)
    return sorted(years)


def filter_chunks_by_year(chunks: List[dict], years: List[str]) -> List[dict]:
    def matches(chunk, year, prev=False):
        text     = chunk.get("text", "")
        doc_name = str(chunk.get("doc_name", ""))
        if prev:
            prev_year = str(int(year) - 1)
            return prev_year in doc_name
        return year in text or year in doc_name

    filtered = [c for c in chunks if any(matches(c, y) for y in years)]
    if filtered:
        return filtered

    adjacent = [c for c in chunks if any(matches(c, y, prev=True) for y in years)]
    if adjacent:
        return adjacent

    return chunks  # pass 3: return all


def translate_to_hindi(text: str) -> str:
    hindi_chars = sum(1 for c in text if '\u0900' <= c <= '\u097F')
    if hindi_chars > 0:
        return text  # already Hindi/Devanagari
    try:
        response = _openai_client.chat.completions.create(
            model=CHAT_DEPLOYMENT,
            messages=[
                {
                    "role": "system",
                    "content": "Translate the English text to Hindi. Return ONLY the Hindi translation, nothing else."
                },
                {"role": "user", "content": text}
            ],
            temperature=0,
            max_tokens=300,
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"[debug] Translation failed: {e}")
        return text


# ── Schema ────────────────────────────────────────────────────────────────────

class DebugChunksRequest(BaseModel):
    query: str


class ChunkDetail(BaseModel):
    chunk_number:    int
    text:            str       # exact text the LLM will see
    doc_name:        str
    page_no:         Optional[str] = None
    years_in_text:   List[str] = []
    char_count:      int
    token_estimate:  int       # chars // 4


class DebugChunksResponse(BaseModel):
    original_query:              str
    translated_query:            str
    years_detected:              List[str]
    fetched_from_vectorstore:    int    # always 40
    after_doc_balancing:         int    # after max 3 per doc
    after_year_filter:           int    # final count sent to LLM
    doc_distribution:            dict   # {doc_name: chunk_count}
    chunks:                      List[ChunkDetail]
    total_context_chars:         int
    total_context_token_estimate: int


# ── Endpoint ──────────────────────────────────────────────────────────────────

@router.post("/chunks", response_model=DebugChunksResponse)
async def get_raw_chunks(body: DebugChunksRequest, request: Request):
    """
    Returns the EXACT chunks the LLM receives — runs the full
    chat_service pipeline (translate → fetch 40 → balance → year filter).

    Toggle this in Streamlit debug mode to see what context the LLM reads.
    """
    vectorstore = request.app.state.vectorstore
    query = body.query

    # Step 1 — Extract years (same as chat_service)
    query_years = extract_years_from_query(query)

    # Step 2 — Translate to Hindi (same as chat_service)
    translated_query = translate_to_hindi(query)

    # Step 3 — Fetch 40 chunks (same fetch_k as chat_service)
    FETCH_K = 40
    raw_chunks = search_vectorstore(translated_query, vectorstore, k=FETCH_K)
    fetched_count = len(raw_chunks)

    # Step 4 — Balance: max 3 per document (same as chat_service)
    MAX_PER_DOC = 3
    doc_counts = {}
    balanced_chunks = []
    for c in raw_chunks:
        doc = c.get("doc_name", "unknown")
        if doc_counts.get(doc, 0) < MAX_PER_DOC:
            balanced_chunks.append(c)
            doc_counts[doc] = doc_counts.get(doc, 0) + 1
    after_balance_count = len(balanced_chunks)

    # Step 5 — Year filter (same as chat_service)
    if query_years:
        final_chunks = filter_chunks_by_year(balanced_chunks, query_years)
    else:
        final_chunks = balanced_chunks
    after_year_count = len(final_chunks)

    # Step 6 — Build response
    chunk_details = []
    for i, chunk in enumerate(final_chunks, 1):
        text = chunk.get("text", "")
        years_in_text = sorted(set(re.findall(r"\b20\d{2}\b", text)))
        chunk_details.append(ChunkDetail(
            chunk_number=i,
            text=text,
            doc_name=chunk.get("doc_name", "unknown"),
            page_no=str(chunk.get("page_no", "?")),
            years_in_text=years_in_text,
            char_count=len(text),
            token_estimate=len(text) // 4,
        ))

    # Doc distribution of final chunks
    final_doc_dist = {}
    for c in final_chunks:
        doc = c.get("doc_name", "unknown")
        final_doc_dist[doc] = final_doc_dist.get(doc, 0) + 1

    combined_text = "\n".join(c.text for c in chunk_details)

    return DebugChunksResponse(
        original_query=query,
        translated_query=translated_query,
        years_detected=query_years,
        fetched_from_vectorstore=fetched_count,
        after_doc_balancing=after_balance_count,
        after_year_filter=after_year_count,
        doc_distribution=final_doc_dist,
        chunks=chunk_details,
        total_context_chars=len(combined_text),
        total_context_token_estimate=len(combined_text) // 4,
    )
