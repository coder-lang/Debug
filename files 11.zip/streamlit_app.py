import streamlit as st
import requests
import os

# -------------------- SESSION STATE --------------------
if "info_messages" not in st.session_state:
    st.session_state.info_messages = []
if "grievance_messages" not in st.session_state:
    st.session_state.grievance_messages = []

# -------------------- CONFIG --------------------
st.set_page_config(page_title="Chat & Grievance Portal", layout="wide")

BACKEND_BASE_URL = os.getenv("BACKEND_BASE_URL", "http://10.40.108.197:8508")
DEFAULT_USER_ID  = os.getenv("DEFAULT_USER_ID", "demo_user")

CHAT_STREAM_URL  = f"{BACKEND_BASE_URL}/chat/stream"
GRIEVANCE_URL    = f"{BACKEND_BASE_URL}/chat/grievance"
DEBUG_CHUNKS_URL = f"{BACKEND_BASE_URL}/debug/chunks"


# -------------------- BACKEND HELPERS --------------------

def stream_llm_output(user_message: str):
    """Streams LLM answer tokens from /chat/stream."""
    payload = {"user_id": DEFAULT_USER_ID, "message": user_message}
    try:
        with requests.post(CHAT_STREAM_URL, json=payload, timeout=180, stream=True) as r:
            r.raise_for_status()
            for piece in r.iter_content(chunk_size=64):
                if piece:
                    yield piece.decode("utf-8", errors="ignore")
    except Exception as e:
        yield f"\n\n⚠️ Streaming error: {e}"


def fetch_raw_rag_chunks(query: str) -> dict:
    """
    Calls POST /debug/chunks — runs the EXACT same pipeline as chat_service:
    translate → fetch 40 → balance (max 3/doc) → year filter.
    Returns the final chunks the LLM will actually receive.
    """
    try:
        r = requests.post(
            DEBUG_CHUNKS_URL,
            json={"query": query},
            timeout=60
        )
        r.raise_for_status()
        return r.json()
    except Exception as e:
        return {"error": str(e)}


def call_backend_grievance(user_message: str) -> dict:
    try:
        r = requests.post(
            GRIEVANCE_URL,
            json={"user_id": DEFAULT_USER_ID, "message": user_message},
            timeout=20
        )
        return r.json()
    except Exception as e:
        return {"message": f"Connection error: {e}"}


# -------------------- UI --------------------
st.title("Uttar Pradesh AI Chatbot")
tab1, tab2 = st.tabs(["🤖 Information Bot", "📢 Raise Grievance"])


# ==================== INFORMATION BOT ====================
with tab1:
    st.subheader("Information Bot")

    col1, col2 = st.columns([3, 1])
    with col2:
        debug_mode = st.checkbox(
            "🔍 Show RAG chunks",
            value=False,
            help=(
                "Runs the exact same pipeline as the chat service:\n"
                "Translate → Fetch 40 → Balance (max 3/doc) → Year filter.\n"
                "What you see here = what the LLM actually receives."
            )
        )

    # Render previous messages
    for msg in st.session_state.info_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"], unsafe_allow_html=True)

    info_input = st.chat_input("Ask something...")

    if info_input:
        st.session_state.info_messages.append({"role": "user", "content": info_input})
        with st.chat_message("user"):
            st.markdown(info_input)

        # ── DEBUG: Exact chunks being passed to LLM ─────────────────────────
        if debug_mode:
            with st.expander("📄 EXACT CHUNKS PASSED TO LLM", expanded=True):
                with st.spinner("Running pipeline: translate → fetch → balance → year filter..."):
                    debug_data = fetch_raw_rag_chunks(info_input)

                if "error" in debug_data:
                    st.error(f"Debug endpoint error: {debug_data['error']}")
                else:
                    # ── Pipeline summary ──────────────────────────────────────
                    st.markdown("#### Pipeline Summary")
                    c1, c2, c3, c4 = st.columns(4)
                    c1.metric("Fetched from vectorstore", debug_data.get("fetched_from_vectorstore", 0), help="fetch_k = 40")
                    c2.metric("After doc balancing",      debug_data.get("after_doc_balancing", 0),      help="max 3 per document")
                    c3.metric("After year filter",        debug_data.get("after_year_filter", 0),        help="final count sent to LLM")
                    c4.metric("~Total tokens",            debug_data.get("total_context_token_estimate", 0))

                    col_a, col_b = st.columns(2)
                    with col_a:
                        orig = debug_data.get("original_query", "")
                        trans = debug_data.get("translated_query", "")
                        st.caption(f"**Original query:** `{orig}`")
                        st.caption(
                            f"**Translated query:** `{trans}`"
                            + (" ✅ (translated)" if trans != orig else " (no translation needed)")
                        )
                    with col_b:
                        years = debug_data.get("years_detected", [])
                        st.caption(f"**Years detected in query:** {years if years else 'None — searching all years'}")
                        dist = debug_data.get("doc_distribution", {})
                        dist_str = " | ".join(f"{k}: {v}" for k, v in dist.items())
                        st.caption(f"**Doc distribution:** {dist_str or 'N/A'}")

                    st.divider()

                    # ── Each chunk ────────────────────────────────────────────
                    st.markdown("#### Chunks (in order sent to LLM)")
                    for chunk in debug_data.get("chunks", []):
                        years_label = (
                            f"Years in text: `{'`, `'.join(chunk['years_in_text'])}`"
                            if chunk.get("years_in_text") else "No years in text"
                        )
                        st.markdown(
                            f"**Chunk #{chunk['chunk_number']}** &nbsp;|&nbsp; "
                            f"📄 `{chunk['doc_name']}` &nbsp;"
                            f"p.{chunk.get('page_no', '?')} &nbsp;|&nbsp; "
                            f"{chunk['char_count']} chars (~{chunk['token_estimate']} tokens) &nbsp;|&nbsp; "
                            f"{years_label}",
                            unsafe_allow_html=True
                        )
                        # ← EXACT text going into LLM context
                        st.code(chunk["text"], language=None)
                        st.divider()

                    st.caption(
                        f"**Total context:** {debug_data.get('total_context_chars', 0)} chars "
                        f"(~{debug_data.get('total_context_token_estimate', 0)} tokens) "
                        f"— this is what the LLM reads before answering."
                    )

        # ── LLM answer (streaming) ───────────────────────────────────────────
        with st.chat_message("assistant"):
            placeholder = st.empty()
            full_answer = ""
            for token in stream_llm_output(info_input):
                full_answer += token
                placeholder.markdown(full_answer, unsafe_allow_html=True)

        st.session_state.info_messages.append({"role": "assistant", "content": full_answer})


# ==================== GRIEVANCE BOT ====================
with tab2:
    st.subheader("Raise a Grievance")

    for msg in st.session_state.grievance_messages:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"], unsafe_allow_html=True)

    grievance_input = st.chat_input("Describe your grievance...")

    if grievance_input:
        st.session_state.grievance_messages.append({"role": "user", "content": grievance_input})

        response = call_backend_grievance(grievance_input)
        status   = response.get("status")
        ticket   = response.get("grievance_id")
        message  = response.get("message", "")

        if status == "success":
            reply = f"""
            <div style='padding:10px;border-left:4px solid green;'>
                <b>✅ Your grievance has been registered successfully!</b><br>
                Ticket Number: <b>{ticket}</b>
            </div>
            """
        else:
            reply = message

        st.session_state.grievance_messages.append({"role": "assistant", "content": reply})
        st.rerun()
